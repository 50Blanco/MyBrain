﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _06_AA_Sparziel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSchließen_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnRechnen_Click(object sender, EventArgs e)
        {
            try
            {
                double anfangsKapital = Convert.ToDouble(txtEingabeAnfangsKapital.Text);
                double endKapital = Convert.ToDouble(txtEingabeEndKapital.Text);
                double zinsSatz = Convert.ToDouble(txtEingabeZinsSatz.Text) / 100;
                double laufZeit = 0;
                double zinsFaktor = 1 + zinsSatz;

                if (endKapital <= anfangsKapital)
                {
                    MessageBox.Show("Das Sparziel muss größer sein als das Anfangskapital");
                    return;
                }

                while (anfangsKapital < endKapital)
                {
                    anfangsKapital *= zinsFaktor;

                    laufZeit++;
                }
                txtAusgabeEndKapital.Text = Math.Round(anfangsKapital, 2).ToString("0.00");
                txtAusgabeDauer.Text = laufZeit.ToString();
            }
            catch
            {
                MessageBox.Show("Bitte geben Sie einen Wert ein!");
            }
        }

        private void btnEingabe_Click(object sender, EventArgs e)
        {

        }
    }
}
