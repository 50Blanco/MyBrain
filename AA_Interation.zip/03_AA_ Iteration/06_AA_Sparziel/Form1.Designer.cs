﻿namespace _06_AA_Sparziel
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtAusgabeEndKapital = new System.Windows.Forms.TextBox();
            this.txtAusgabeDauer = new System.Windows.Forms.TextBox();
            this.txtEingabeZinsSatz = new System.Windows.Forms.TextBox();
            this.txtEingabeEndKapital = new System.Windows.Forms.TextBox();
            this.btnSchließen = new System.Windows.Forms.Button();
            this.btnEingabe = new System.Windows.Forms.Button();
            this.btnRechnen = new System.Windows.Forms.Button();
            this.txtEingabeAnfangsKapital = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtAusgabeEndKapital
            // 
            this.txtAusgabeEndKapital.Location = new System.Drawing.Point(216, 131);
            this.txtAusgabeEndKapital.Margin = new System.Windows.Forms.Padding(2);
            this.txtAusgabeEndKapital.Name = "txtAusgabeEndKapital";
            this.txtAusgabeEndKapital.ReadOnly = true;
            this.txtAusgabeEndKapital.Size = new System.Drawing.Size(76, 20);
            this.txtAusgabeEndKapital.TabIndex = 25;
            this.txtAusgabeEndKapital.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtAusgabeDauer
            // 
            this.txtAusgabeDauer.Location = new System.Drawing.Point(215, 107);
            this.txtAusgabeDauer.Margin = new System.Windows.Forms.Padding(2);
            this.txtAusgabeDauer.Name = "txtAusgabeDauer";
            this.txtAusgabeDauer.ReadOnly = true;
            this.txtAusgabeDauer.Size = new System.Drawing.Size(76, 20);
            this.txtAusgabeDauer.TabIndex = 24;
            this.txtAusgabeDauer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtEingabeZinsSatz
            // 
            this.txtEingabeZinsSatz.Location = new System.Drawing.Point(217, 82);
            this.txtEingabeZinsSatz.Margin = new System.Windows.Forms.Padding(2);
            this.txtEingabeZinsSatz.Name = "txtEingabeZinsSatz";
            this.txtEingabeZinsSatz.Size = new System.Drawing.Size(76, 20);
            this.txtEingabeZinsSatz.TabIndex = 23;
            this.txtEingabeZinsSatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtEingabeEndKapital
            // 
            this.txtEingabeEndKapital.Location = new System.Drawing.Point(218, 53);
            this.txtEingabeEndKapital.Margin = new System.Windows.Forms.Padding(2);
            this.txtEingabeEndKapital.Name = "txtEingabeEndKapital";
            this.txtEingabeEndKapital.Size = new System.Drawing.Size(76, 20);
            this.txtEingabeEndKapital.TabIndex = 22;
            this.txtEingabeEndKapital.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnSchließen
            // 
            this.btnSchließen.Location = new System.Drawing.Point(292, 210);
            this.btnSchließen.Margin = new System.Windows.Forms.Padding(2);
            this.btnSchließen.Name = "btnSchließen";
            this.btnSchließen.Size = new System.Drawing.Size(56, 27);
            this.btnSchließen.TabIndex = 21;
            this.btnSchließen.Text = "Schließen";
            this.btnSchließen.UseVisualStyleBackColor = true;
            this.btnSchließen.Click += new System.EventHandler(this.btnSchließen_Click);
            // 
            // btnEingabe
            // 
            this.btnEingabe.Location = new System.Drawing.Point(153, 210);
            this.btnEingabe.Margin = new System.Windows.Forms.Padding(2);
            this.btnEingabe.Name = "btnEingabe";
            this.btnEingabe.Size = new System.Drawing.Size(97, 27);
            this.btnEingabe.TabIndex = 20;
            this.btnEingabe.Text = "Neue Eingabe";
            this.btnEingabe.UseVisualStyleBackColor = true;
            this.btnEingabe.Click += new System.EventHandler(this.btnEingabe_Click);
            // 
            // btnRechnen
            // 
            this.btnRechnen.Location = new System.Drawing.Point(57, 210);
            this.btnRechnen.Margin = new System.Windows.Forms.Padding(2);
            this.btnRechnen.Name = "btnRechnen";
            this.btnRechnen.Size = new System.Drawing.Size(56, 27);
            this.btnRechnen.TabIndex = 19;
            this.btnRechnen.Text = "Rechnen";
            this.btnRechnen.UseVisualStyleBackColor = true;
            this.btnRechnen.Click += new System.EventHandler(this.btnRechnen_Click);
            // 
            // txtEingabeAnfangsKapital
            // 
            this.txtEingabeAnfangsKapital.Location = new System.Drawing.Point(213, 27);
            this.txtEingabeAnfangsKapital.Margin = new System.Windows.Forms.Padding(2);
            this.txtEingabeAnfangsKapital.Name = "txtEingabeAnfangsKapital";
            this.txtEingabeAnfangsKapital.Size = new System.Drawing.Size(76, 20);
            this.txtEingabeAnfangsKapital.TabIndex = 18;
            this.txtEingabeAnfangsKapital.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(117, 136);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "Endkapital in Euro";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(98, 112);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Anlagedauer in Jahren";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(140, 87);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "Zinssatz in %";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(55, 58);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(161, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "Gewünschtes Endkapital in Euro";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(98, 32);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Anfangskapital in Euro";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(395, 325);
            this.Controls.Add(this.txtAusgabeEndKapital);
            this.Controls.Add(this.txtAusgabeDauer);
            this.Controls.Add(this.txtEingabeZinsSatz);
            this.Controls.Add(this.txtEingabeEndKapital);
            this.Controls.Add(this.btnSchließen);
            this.Controls.Add(this.btnEingabe);
            this.Controls.Add(this.btnRechnen);
            this.Controls.Add(this.txtEingabeAnfangsKapital);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtAusgabeEndKapital;
        private System.Windows.Forms.TextBox txtAusgabeDauer;
        private System.Windows.Forms.TextBox txtEingabeZinsSatz;
        private System.Windows.Forms.TextBox txtEingabeEndKapital;
        private System.Windows.Forms.Button btnSchließen;
        private System.Windows.Forms.Button btnEingabe;
        private System.Windows.Forms.Button btnRechnen;
        private System.Windows.Forms.TextBox txtEingabeAnfangsKapital;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

