﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _08_AA_MethodenListBox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Aufgabe 1
            //Wertezum Füllen des Listenfelds in einem Array speichern
            string[] gerichte = { "Spaghetti, Grüne Nudeln, Tortellini, Pizza, Lasagne" };

            lstSpeiseKarte.Items.AddRange(gerichte);
        }

        //Aufgabe 2: Ausgewählte Element löschen
        private void btnElementeLöschen_Click(object sender, EventArgs e)
        {
            //Remove entfernt das ausgewählte Element
            lstSpeiseKarte.Items.Remove(lstSpeiseKarte.SelectedItem);
        }

        //Aufgabe 3: Ausgewählte Elemente ersetzen
        private void btnElementeErsetzen_Click(object sender, EventArgs e)
        {
            //Fehlermeldung und Abbruch, falls keine Nutzereingabe erfolgt
            if (txtEingabeErsatz.Text == "")
            {
                MessageBox.Show("Geben Sie bitte ein, durch welches Gericht " +
                    " das in der Liste ausgewählte ersetzt werden soll.");
                return; //der weitere Programmablauf wird abgebrochen
            }
            if (lstSpeiseKarte.SelectedIndex == -1)
            {
                MessageBox.Show("Bitte wählen Sie in der Speisekarte ein Gericht aus, " +
                    "das ersetzt werden soll.");
                return;
            }

            //An dem Index des in der Listbox ausgewählten Elements
            //wird das "Ersatzelement" aus der Textbox geschrieben
            lstSpeiseKarte.Items.Insert(lstSpeiseKarte.SelectedIndex, txtEingabeErsatz.Text);

            //Das vom Nutzer in der Listbox ausgewählte Element wird anschließend gelöscht
            //Verwendung von Remove mit dem SelectedItem oder RemoveAt mit dem SelectesIndex
            lstSpeiseKarte.Items.Remove(lstSpeiseKarte.SelectedItem);
            txtEingabeErsatz.Clear();

            //Aufgabe 4: Neues Element an gewünschter Stelle einfügen


        }

        private void btnNeuesElementEinfügen_Click(object sender, EventArgs e)
        {
            //Fehlermeldung und Abbruch, falls keine Nutzereingabe erfolgt
            if (txtEingabeNeu.Text == "")
            {
                MessageBox.Show("Geben Sie bitte ein, welches Gericht neu in die " +
                    " Liste aufgenommen werden soll.");
                return;
            }
            if (rBtnAnfangListe.Checked)
            {
                lstSpeiseKarte.Items.Insert(0, txtEingabeNeu.Text);
            }
            else
            {
                if (lstSpeiseKarte.SelectedIndex == -1)
                {
                    MessageBox.Show("Bitte wählen Sie in der Speisekarte das Gericht aus, " +
                    "vor dem das Neue eingesetzt werden soll.");
                    return;
                }
       
                lstSpeiseKarte.Items.Insert(lstSpeiseKarte.SelectedIndex, txtEingabeNeu.Text);
            else
                {
                    lstSpeiseKarte.Items.Add(txtEingabeNeu.Text);
                }

            }
        }
        //Aufgabe 5
        private void btnAufTagesKarte_Click(object sender, EventArgs e)
        {
            for(int i = 0; i < lstSpeiseKarte.SelectedItems.Count; i++)
            {
                lstTagesKarte.Items.Add(lstSpeiseKarte.SelectedItems[i]);
            }

            for(int i = lstSpeiseKarte.SelectedItems.Count - 1; i >= 0; i--)
            {
                lstSpeiseKarte.Items.RemoveAt(lstSpeiseKarte.SelectedIndices[i]);
            }
        }
        //Aufgabe 6
        private void btnZurSpeiseKarte_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstTagesKarte.SelectedItems.Count; i++)
            {
                lstSpeiseKarte.Items.Add(lstTagesKarte.SelectedItems[i]);
            }
            
            for (int i = lstTagesKarte.SelectedItems.Count - 1; i >= 0; i--)
            {
                lstTagesKarte.Items.RemoveAt(lstTagesKarte.SelectedIndices[i]);
            }
        }

        private void btnTagesKarteLöschen_Click(object sender, EventArgs e)
        {
            lstTagesKarte.Items.Clear();
        }
    }
}

