﻿namespace _08_AA_MethodenListBox
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTagesKarteLöschen = new System.Windows.Forms.Button();
            this.btnZurSpeiseKarte = new System.Windows.Forms.Button();
            this.btnAufTagesKarte = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rBtnAnfangListe = new System.Windows.Forms.RadioButton();
            this.rBtnVorAuswahl = new System.Windows.Forms.RadioButton();
            this.rBtnEndeListe = new System.Windows.Forms.RadioButton();
            this.btnNeuesElementEinfügen = new System.Windows.Forms.Button();
            this.txtEingabeNeu = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtEingabeErsatz = new System.Windows.Forms.TextBox();
            this.btnElementeErsetzen = new System.Windows.Forms.Button();
            this.btnElementeLöschen = new System.Windows.Forms.Button();
            this.lstTagesKarte = new System.Windows.Forms.ListBox();
            this.lstSpeiseKarte = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnTagesKarteLöschen
            // 
            this.btnTagesKarteLöschen.Location = new System.Drawing.Point(450, 169);
            this.btnTagesKarteLöschen.Margin = new System.Windows.Forms.Padding(2);
            this.btnTagesKarteLöschen.Name = "btnTagesKarteLöschen";
            this.btnTagesKarteLöschen.Size = new System.Drawing.Size(214, 36);
            this.btnTagesKarteLöschen.TabIndex = 72;
            this.btnTagesKarteLöschen.Text = "Tageskarte löschen";
            this.btnTagesKarteLöschen.UseVisualStyleBackColor = true;
            this.btnTagesKarteLöschen.Click += new System.EventHandler(this.btnTagesKarteLöschen_Click);
            // 
            // btnZurSpeiseKarte
            // 
            this.btnZurSpeiseKarte.Location = new System.Drawing.Point(318, 93);
            this.btnZurSpeiseKarte.Margin = new System.Windows.Forms.Padding(2);
            this.btnZurSpeiseKarte.Name = "btnZurSpeiseKarte";
            this.btnZurSpeiseKarte.Size = new System.Drawing.Size(112, 33);
            this.btnZurSpeiseKarte.TabIndex = 71;
            this.btnZurSpeiseKarte.Text = "<< Zur Speisekarte";
            this.btnZurSpeiseKarte.UseVisualStyleBackColor = true;
            this.btnZurSpeiseKarte.Click += new System.EventHandler(this.btnZurSpeiseKarte_Click);
            // 
            // btnAufTagesKarte
            // 
            this.btnAufTagesKarte.Location = new System.Drawing.Point(318, 50);
            this.btnAufTagesKarte.Margin = new System.Windows.Forms.Padding(2);
            this.btnAufTagesKarte.Name = "btnAufTagesKarte";
            this.btnAufTagesKarte.Size = new System.Drawing.Size(112, 33);
            this.btnAufTagesKarte.TabIndex = 70;
            this.btnAufTagesKarte.Text = ">> Zur Tageskarte";
            this.btnAufTagesKarte.UseVisualStyleBackColor = true;
            this.btnAufTagesKarte.Click += new System.EventHandler(this.btnAufTagesKarte_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rBtnAnfangListe);
            this.groupBox1.Controls.Add(this.rBtnVorAuswahl);
            this.groupBox1.Controls.Add(this.rBtnEndeListe);
            this.groupBox1.Location = new System.Drawing.Point(85, 347);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(216, 109);
            this.groupBox1.TabIndex = 69;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Wo soll das Element eingefügt werden?";
            // 
            // rBtnAnfangListe
            // 
            this.rBtnAnfangListe.AutoSize = true;
            this.rBtnAnfangListe.Location = new System.Drawing.Point(18, 51);
            this.rBtnAnfangListe.Margin = new System.Windows.Forms.Padding(2);
            this.rBtnAnfangListe.Name = "rBtnAnfangListe";
            this.rBtnAnfangListe.Size = new System.Drawing.Size(120, 17);
            this.rBtnAnfangListe.TabIndex = 10;
            this.rBtnAnfangListe.Text = "Am Anfang der Liste";
            this.rBtnAnfangListe.UseVisualStyleBackColor = true;
            // 
            // rBtnVorAuswahl
            // 
            this.rBtnVorAuswahl.AutoSize = true;
            this.rBtnVorAuswahl.Location = new System.Drawing.Point(18, 72);
            this.rBtnVorAuswahl.Margin = new System.Windows.Forms.Padding(2);
            this.rBtnVorAuswahl.Name = "rBtnVorAuswahl";
            this.rBtnVorAuswahl.Size = new System.Drawing.Size(170, 17);
            this.rBtnVorAuswahl.TabIndex = 11;
            this.rBtnVorAuswahl.Text = "Vor dem ausgewählten Gericht";
            this.rBtnVorAuswahl.UseVisualStyleBackColor = true;
            // 
            // rBtnEndeListe
            // 
            this.rBtnEndeListe.AutoSize = true;
            this.rBtnEndeListe.Checked = true;
            this.rBtnEndeListe.Location = new System.Drawing.Point(18, 27);
            this.rBtnEndeListe.Margin = new System.Windows.Forms.Padding(2);
            this.rBtnEndeListe.Name = "rBtnEndeListe";
            this.rBtnEndeListe.Size = new System.Drawing.Size(111, 17);
            this.rBtnEndeListe.TabIndex = 9;
            this.rBtnEndeListe.TabStop = true;
            this.rBtnEndeListe.Text = "Am Ende der Liste";
            this.rBtnEndeListe.UseVisualStyleBackColor = true;
            // 
            // btnNeuesElementEinfügen
            // 
            this.btnNeuesElementEinfügen.Location = new System.Drawing.Point(85, 469);
            this.btnNeuesElementEinfügen.Margin = new System.Windows.Forms.Padding(2);
            this.btnNeuesElementEinfügen.Name = "btnNeuesElementEinfügen";
            this.btnNeuesElementEinfügen.Size = new System.Drawing.Size(203, 36);
            this.btnNeuesElementEinfügen.TabIndex = 68;
            this.btnNeuesElementEinfügen.Text = "Neues Gericht einfügen";
            this.btnNeuesElementEinfügen.UseVisualStyleBackColor = true;
            this.btnNeuesElementEinfügen.Click += new System.EventHandler(this.btnNeuesElementEinfügen_Click);
            // 
            // txtEingabeNeu
            // 
            this.txtEingabeNeu.Location = new System.Drawing.Point(167, 314);
            this.txtEingabeNeu.Margin = new System.Windows.Forms.Padding(2);
            this.txtEingabeNeu.Name = "txtEingabeNeu";
            this.txtEingabeNeu.Size = new System.Drawing.Size(122, 20);
            this.txtEingabeNeu.TabIndex = 67;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(82, 315);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 66;
            this.label1.Text = "Neues Gericht:";
            // 
            // txtEingabeErsatz
            // 
            this.txtEingabeErsatz.Location = new System.Drawing.Point(310, 239);
            this.txtEingabeErsatz.Margin = new System.Windows.Forms.Padding(2);
            this.txtEingabeErsatz.Name = "txtEingabeErsatz";
            this.txtEingabeErsatz.Size = new System.Drawing.Size(122, 20);
            this.txtEingabeErsatz.TabIndex = 65;
            // 
            // btnElementeErsetzen
            // 
            this.btnElementeErsetzen.Location = new System.Drawing.Point(86, 230);
            this.btnElementeErsetzen.Margin = new System.Windows.Forms.Padding(2);
            this.btnElementeErsetzen.Name = "btnElementeErsetzen";
            this.btnElementeErsetzen.Size = new System.Drawing.Size(214, 36);
            this.btnElementeErsetzen.TabIndex = 64;
            this.btnElementeErsetzen.Text = "Ausgewähltes Gericht ersetzten durch:";
            this.btnElementeErsetzen.UseVisualStyleBackColor = true;
            this.btnElementeErsetzen.Click += new System.EventHandler(this.btnElementeErsetzen_Click);
            // 
            // btnElementeLöschen
            // 
            this.btnElementeLöschen.Location = new System.Drawing.Point(86, 169);
            this.btnElementeLöschen.Margin = new System.Windows.Forms.Padding(2);
            this.btnElementeLöschen.Name = "btnElementeLöschen";
            this.btnElementeLöschen.Size = new System.Drawing.Size(214, 36);
            this.btnElementeLöschen.TabIndex = 63;
            this.btnElementeLöschen.Text = "Ausgewähltes Gericht löschen";
            this.btnElementeLöschen.UseVisualStyleBackColor = true;
            this.btnElementeLöschen.Click += new System.EventHandler(this.btnElementeLöschen_Click);
            // 
            // lstTagesKarte
            // 
            this.lstTagesKarte.FormattingEnabled = true;
            this.lstTagesKarte.Location = new System.Drawing.Point(450, 30);
            this.lstTagesKarte.Margin = new System.Windows.Forms.Padding(2);
            this.lstTagesKarte.Name = "lstTagesKarte";
            this.lstTagesKarte.Size = new System.Drawing.Size(216, 108);
            this.lstTagesKarte.TabIndex = 62;
            // 
            // lstSpeiseKarte
            // 
            this.lstSpeiseKarte.FormattingEnabled = true;
            this.lstSpeiseKarte.Location = new System.Drawing.Point(86, 30);
            this.lstSpeiseKarte.Margin = new System.Windows.Forms.Padding(2);
            this.lstSpeiseKarte.Name = "lstSpeiseKarte";
            this.lstSpeiseKarte.Size = new System.Drawing.Size(216, 121);
            this.lstSpeiseKarte.TabIndex = 61;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 548);
            this.Controls.Add(this.btnTagesKarteLöschen);
            this.Controls.Add(this.btnZurSpeiseKarte);
            this.Controls.Add(this.btnAufTagesKarte);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnNeuesElementEinfügen);
            this.Controls.Add(this.txtEingabeNeu);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtEingabeErsatz);
            this.Controls.Add(this.btnElementeErsetzen);
            this.Controls.Add(this.btnElementeLöschen);
            this.Controls.Add(this.lstTagesKarte);
            this.Controls.Add(this.lstSpeiseKarte);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTagesKarteLöschen;
        private System.Windows.Forms.Button btnZurSpeiseKarte;
        private System.Windows.Forms.Button btnAufTagesKarte;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rBtnAnfangListe;
        private System.Windows.Forms.RadioButton rBtnVorAuswahl;
        private System.Windows.Forms.RadioButton rBtnEndeListe;
        private System.Windows.Forms.Button btnNeuesElementEinfügen;
        private System.Windows.Forms.TextBox txtEingabeNeu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtEingabeErsatz;
        private System.Windows.Forms.Button btnElementeErsetzen;
        private System.Windows.Forms.Button btnElementeLöschen;
        private System.Windows.Forms.ListBox lstTagesKarte;
        private System.Windows.Forms.ListBox lstSpeiseKarte;
    }
}

