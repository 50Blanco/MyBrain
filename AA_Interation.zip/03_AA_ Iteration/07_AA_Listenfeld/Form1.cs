﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _07_AA_Listenfeld
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //lstSpeisen.Items.Add("Spaghetti");//Index 0
            //lstSpeisen.Items.Add("Grüne Nudeln");//Index 1
            //lstSpeisen.Items.Add("Tortellini");//Index 2
            //lstSpeisen.Items.Add("Pizza");//Index 3
            //lstSpeisen.Items.Add("Lasagne");//Index 4

            //Alternative dazu: Werte in einem Array speichern und 
            //alle Werte des Arrays der Listbox hinzufügen
            string[] gerichte = { "Spaghetti", "Grüne Nudeln", "Tortellini", "Pizza", "Lasagne" };
            lstSpeisen.Items.AddRange(gerichte);

            lstSpeisen.SelectedIndex = 0;
        }
        private void btnAnzeige_Click(object sender, EventArgs e)
        {
            lblAusgabe1.Text = "Anzahl: " + lstSpeisen.Items.Count;

            lblAusgabe2.Text = "Ausgewählter Eintrag: " + lstSpeisen.SelectedItem;

            lblAusgabe3.Text = "Nummer des Ausgewählten Eintrags: " + lstSpeisen.SelectedIndex;

            lblAusgabe4.Text = "Alle Einträge:" + "\n";

            for (int i = 0; i < lstSpeisen.Items.Count; i++)
            {
                lblAusgabe4.Text += lstSpeisen.Items[i] + "\n";
            }
        }

        
    }
}
