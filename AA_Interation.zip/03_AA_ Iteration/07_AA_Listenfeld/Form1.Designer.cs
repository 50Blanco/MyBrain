﻿namespace _07_AA_Listenfeld
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAusgabe4 = new System.Windows.Forms.Label();
            this.lblAusgabe3 = new System.Windows.Forms.Label();
            this.lblAusgabe2 = new System.Windows.Forms.Label();
            this.lblAusgabe1 = new System.Windows.Forms.Label();
            this.btnAnzeige = new System.Windows.Forms.Button();
            this.lstSpeisen = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lblAusgabe4
            // 
            this.lblAusgabe4.AutoSize = true;
            this.lblAusgabe4.Location = new System.Drawing.Point(27, 233);
            this.lblAusgabe4.Name = "lblAusgabe4";
            this.lblAusgabe4.Size = new System.Drawing.Size(10, 13);
            this.lblAusgabe4.TabIndex = 11;
            this.lblAusgabe4.Text = "-";
            // 
            // lblAusgabe3
            // 
            this.lblAusgabe3.AutoSize = true;
            this.lblAusgabe3.Location = new System.Drawing.Point(27, 206);
            this.lblAusgabe3.Name = "lblAusgabe3";
            this.lblAusgabe3.Size = new System.Drawing.Size(10, 13);
            this.lblAusgabe3.TabIndex = 10;
            this.lblAusgabe3.Text = "-";
            // 
            // lblAusgabe2
            // 
            this.lblAusgabe2.AutoSize = true;
            this.lblAusgabe2.Location = new System.Drawing.Point(27, 171);
            this.lblAusgabe2.Name = "lblAusgabe2";
            this.lblAusgabe2.Size = new System.Drawing.Size(10, 13);
            this.lblAusgabe2.TabIndex = 9;
            this.lblAusgabe2.Text = "-";
            // 
            // lblAusgabe1
            // 
            this.lblAusgabe1.AutoSize = true;
            this.lblAusgabe1.Location = new System.Drawing.Point(27, 139);
            this.lblAusgabe1.Name = "lblAusgabe1";
            this.lblAusgabe1.Size = new System.Drawing.Size(10, 13);
            this.lblAusgabe1.TabIndex = 8;
            this.lblAusgabe1.Text = "-";
            // 
            // btnAnzeige
            // 
            this.btnAnzeige.Location = new System.Drawing.Point(154, 27);
            this.btnAnzeige.Name = "btnAnzeige";
            this.btnAnzeige.Size = new System.Drawing.Size(75, 30);
            this.btnAnzeige.TabIndex = 7;
            this.btnAnzeige.Text = "Anzeige";
            this.btnAnzeige.UseVisualStyleBackColor = true;
            this.btnAnzeige.Click += new System.EventHandler(this.btnAnzeige_Click);
            // 
            // lstSpeisen
            // 
            this.lstSpeisen.FormattingEnabled = true;
            this.lstSpeisen.Location = new System.Drawing.Point(27, 27);
            this.lstSpeisen.Name = "lstSpeisen";
            this.lstSpeisen.Size = new System.Drawing.Size(120, 95);
            this.lstSpeisen.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblAusgabe4);
            this.Controls.Add(this.lblAusgabe3);
            this.Controls.Add(this.lblAusgabe2);
            this.Controls.Add(this.lblAusgabe1);
            this.Controls.Add(this.btnAnzeige);
            this.Controls.Add(this.lstSpeisen);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAusgabe4;
        private System.Windows.Forms.Label lblAusgabe3;
        private System.Windows.Forms.Label lblAusgabe2;
        private System.Windows.Forms.Label lblAusgabe1;
        private System.Windows.Forms.Button btnAnzeige;
        private System.Windows.Forms.ListBox lstSpeisen;
    }
}

