﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _04_AA_Halbierung
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAnzeige_Click(object sender, EventArgs e)
        {
            try
            {
                double d = Convert.ToDouble(txtEingabeZahl.Text);

                lblSchleife.Text = "";

                while (d >= 0.001)
                {
                    d /= 2; //Kurzform für d = d / 2;

                    lblSchleife.Text += d + "\n";
                }
            }
            catch
            {
                MessageBox.Show("Bitte geben Sie eine Zahl in das Textfeld");
            }
        }
    }
}
