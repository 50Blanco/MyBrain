﻿namespace _04_AA_Halbierung
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSchleife = new System.Windows.Forms.Label();
            this.btnAnzeige = new System.Windows.Forms.Button();
            this.txtEingabeZahl = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblSchleife
            // 
            this.lblSchleife.AutoSize = true;
            this.lblSchleife.Location = new System.Drawing.Point(141, 39);
            this.lblSchleife.Name = "lblSchleife";
            this.lblSchleife.Size = new System.Drawing.Size(10, 13);
            this.lblSchleife.TabIndex = 5;
            this.lblSchleife.Text = "-";
            // 
            // btnAnzeige
            // 
            this.btnAnzeige.Location = new System.Drawing.Point(34, 60);
            this.btnAnzeige.Name = "btnAnzeige";
            this.btnAnzeige.Size = new System.Drawing.Size(75, 23);
            this.btnAnzeige.TabIndex = 4;
            this.btnAnzeige.Text = "Anzeige";
            this.btnAnzeige.UseVisualStyleBackColor = true;
            this.btnAnzeige.Click += new System.EventHandler(this.btnAnzeige_Click);
            // 
            // txtEingabeZahl
            // 
            this.txtEingabeZahl.Location = new System.Drawing.Point(34, 33);
            this.txtEingabeZahl.Name = "txtEingabeZahl";
            this.txtEingabeZahl.Size = new System.Drawing.Size(100, 20);
            this.txtEingabeZahl.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(332, 217);
            this.Controls.Add(this.lblSchleife);
            this.Controls.Add(this.btnAnzeige);
            this.Controls.Add(this.txtEingabeZahl);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSchleife;
        private System.Windows.Forms.Button btnAnzeige;
        private System.Windows.Forms.TextBox txtEingabeZahl;
    }
}

