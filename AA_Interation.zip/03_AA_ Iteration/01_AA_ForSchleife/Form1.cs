﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _01_AA_ForSchleife
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSchleife1_Click(object sender, EventArgs e)
        {
            int i; //Schleifenvariable
            lblSchleife1.Text = ""; //Label leeren

            for (i = 3; i <= 7; i++)    //Startausdruck; Laufbedingung; Änderung
            {
                lblSchleife1.Text += i + "\n"; //Ausgabe der Werte der Schleifenvariablen
            }
        }

        private void btnSchleife2_Click(object sender, EventArgs e)
        {
            int i;
            lblSchleife2.Text = "";

            for (i = 3; i <= 11; i = i + 2)
            {
                lblSchleife2.Text += i + "\n";
            }
        }

        private void btnSchleife3_Click(object sender, EventArgs e)
        {
            int i;
            lblSchleife3.Text = "";

            for (i = 7; i >= 3; i--)
            {
                lblSchleife3.Text += i + "\n";
            }
        }

        private void btnSchleife4_Click(object sender, EventArgs e)
        {
            double d;
            lblSchleife4.Text = "";

            for (d = 3.5; d <= 6.5; d = d + 1.5)
            {
                lblSchleife4.Text += d + "\n";
            }
        }

        private void btnSchleife5_Click(object sender, EventArgs e)
        {
            int i;
            lblSchleife5.Text = "";
            for (i = 3; i <= 20; i++) // (Startausdruck; Laufbedingung; Änderung)
            {
                if (i >= 5 && i <= 7)
                    continue;
                if (i >= 11)
                    break;
                lblSchleife5.Text += i + "\n"; // Ausgabe der Werte der Schleifenvariablen
            }
        }
    }
}
