﻿namespace _01_AA_ForSchleife
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSchleife1 = new System.Windows.Forms.Button();
            this.btnSchleife2 = new System.Windows.Forms.Button();
            this.btnSchleife3 = new System.Windows.Forms.Button();
            this.btnSchleife4 = new System.Windows.Forms.Button();
            this.btnSchleife5 = new System.Windows.Forms.Button();
            this.lblSchleife1 = new System.Windows.Forms.Label();
            this.lblSchleife2 = new System.Windows.Forms.Label();
            this.lblSchleife3 = new System.Windows.Forms.Label();
            this.lblSchleife4 = new System.Windows.Forms.Label();
            this.lblSchleife5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnSchleife1
            // 
            this.btnSchleife1.Location = new System.Drawing.Point(76, 28);
            this.btnSchleife1.Name = "btnSchleife1";
            this.btnSchleife1.Size = new System.Drawing.Size(75, 23);
            this.btnSchleife1.TabIndex = 0;
            this.btnSchleife1.Text = "Schleife 1";
            this.btnSchleife1.UseVisualStyleBackColor = true;
            this.btnSchleife1.Click += new System.EventHandler(this.btnSchleife1_Click);
            // 
            // btnSchleife2
            // 
            this.btnSchleife2.Location = new System.Drawing.Point(179, 28);
            this.btnSchleife2.Name = "btnSchleife2";
            this.btnSchleife2.Size = new System.Drawing.Size(75, 23);
            this.btnSchleife2.TabIndex = 1;
            this.btnSchleife2.Text = "Schleife 2";
            this.btnSchleife2.UseVisualStyleBackColor = true;
            this.btnSchleife2.Click += new System.EventHandler(this.btnSchleife2_Click);
            // 
            // btnSchleife3
            // 
            this.btnSchleife3.Location = new System.Drawing.Point(274, 28);
            this.btnSchleife3.Name = "btnSchleife3";
            this.btnSchleife3.Size = new System.Drawing.Size(75, 23);
            this.btnSchleife3.TabIndex = 2;
            this.btnSchleife3.Text = "Schleife 3";
            this.btnSchleife3.UseVisualStyleBackColor = true;
            this.btnSchleife3.Click += new System.EventHandler(this.btnSchleife3_Click);
            // 
            // btnSchleife4
            // 
            this.btnSchleife4.Location = new System.Drawing.Point(379, 28);
            this.btnSchleife4.Name = "btnSchleife4";
            this.btnSchleife4.Size = new System.Drawing.Size(75, 23);
            this.btnSchleife4.TabIndex = 3;
            this.btnSchleife4.Text = "Schleife 4";
            this.btnSchleife4.UseVisualStyleBackColor = true;
            this.btnSchleife4.Click += new System.EventHandler(this.btnSchleife4_Click);
            // 
            // btnSchleife5
            // 
            this.btnSchleife5.Location = new System.Drawing.Point(481, 28);
            this.btnSchleife5.Name = "btnSchleife5";
            this.btnSchleife5.Size = new System.Drawing.Size(75, 23);
            this.btnSchleife5.TabIndex = 4;
            this.btnSchleife5.Text = "Schleife 5";
            this.btnSchleife5.UseVisualStyleBackColor = true;
            this.btnSchleife5.Click += new System.EventHandler(this.btnSchleife5_Click);
            // 
            // lblSchleife1
            // 
            this.lblSchleife1.AutoSize = true;
            this.lblSchleife1.Location = new System.Drawing.Point(76, 77);
            this.lblSchleife1.Name = "lblSchleife1";
            this.lblSchleife1.Size = new System.Drawing.Size(10, 13);
            this.lblSchleife1.TabIndex = 5;
            this.lblSchleife1.Text = "-";
            // 
            // lblSchleife2
            // 
            this.lblSchleife2.AutoSize = true;
            this.lblSchleife2.Location = new System.Drawing.Point(176, 77);
            this.lblSchleife2.Name = "lblSchleife2";
            this.lblSchleife2.Size = new System.Drawing.Size(10, 13);
            this.lblSchleife2.TabIndex = 6;
            this.lblSchleife2.Text = "-";
            // 
            // lblSchleife3
            // 
            this.lblSchleife3.AutoSize = true;
            this.lblSchleife3.Location = new System.Drawing.Point(271, 77);
            this.lblSchleife3.Name = "lblSchleife3";
            this.lblSchleife3.Size = new System.Drawing.Size(10, 13);
            this.lblSchleife3.TabIndex = 7;
            this.lblSchleife3.Text = "-";
            // 
            // lblSchleife4
            // 
            this.lblSchleife4.AutoSize = true;
            this.lblSchleife4.Location = new System.Drawing.Point(376, 77);
            this.lblSchleife4.Name = "lblSchleife4";
            this.lblSchleife4.Size = new System.Drawing.Size(10, 13);
            this.lblSchleife4.TabIndex = 8;
            this.lblSchleife4.Text = "-";
            // 
            // lblSchleife5
            // 
            this.lblSchleife5.AutoSize = true;
            this.lblSchleife5.Location = new System.Drawing.Point(482, 77);
            this.lblSchleife5.Name = "lblSchleife5";
            this.lblSchleife5.Size = new System.Drawing.Size(10, 13);
            this.lblSchleife5.TabIndex = 9;
            this.lblSchleife5.Text = "-";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblSchleife5);
            this.Controls.Add(this.lblSchleife4);
            this.Controls.Add(this.lblSchleife3);
            this.Controls.Add(this.lblSchleife2);
            this.Controls.Add(this.lblSchleife1);
            this.Controls.Add(this.btnSchleife5);
            this.Controls.Add(this.btnSchleife4);
            this.Controls.Add(this.btnSchleife3);
            this.Controls.Add(this.btnSchleife2);
            this.Controls.Add(this.btnSchleife1);
            this.Name = "Form1";
            this.Text = "For-Schleife";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSchleife1;
        private System.Windows.Forms.Button btnSchleife2;
        private System.Windows.Forms.Button btnSchleife3;
        private System.Windows.Forms.Button btnSchleife4;
        private System.Windows.Forms.Button btnSchleife5;
        private System.Windows.Forms.Label lblSchleife1;
        private System.Windows.Forms.Label lblSchleife2;
        private System.Windows.Forms.Label lblSchleife3;
        private System.Windows.Forms.Label lblSchleife4;
        private System.Windows.Forms.Label lblSchleife5;
    }
}

