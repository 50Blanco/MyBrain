﻿namespace _02_AA_ÜbungForSchleife
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtAusgabeSumme = new System.Windows.Forms.TextBox();
            this.txtAusgabeMittelwert = new System.Windows.Forms.TextBox();
            this.btnAusgabe = new System.Windows.Forms.Button();
            this.txtAusgabeZahl = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(351, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ausgabe der Zahlen zwischen 35 und 20 in absteigenden 2,5er Schritten";
            // 
            // txtAusgabeSumme
            // 
            this.txtAusgabeSumme.Location = new System.Drawing.Point(72, 223);
            this.txtAusgabeSumme.Name = "txtAusgabeSumme";
            this.txtAusgabeSumme.ReadOnly = true;
            this.txtAusgabeSumme.Size = new System.Drawing.Size(100, 20);
            this.txtAusgabeSumme.TabIndex = 2;
            // 
            // txtAusgabeMittelwert
            // 
            this.txtAusgabeMittelwert.Location = new System.Drawing.Point(72, 273);
            this.txtAusgabeMittelwert.Name = "txtAusgabeMittelwert";
            this.txtAusgabeMittelwert.ReadOnly = true;
            this.txtAusgabeMittelwert.Size = new System.Drawing.Size(100, 20);
            this.txtAusgabeMittelwert.TabIndex = 3;
            // 
            // btnAusgabe
            // 
            this.btnAusgabe.Location = new System.Drawing.Point(221, 79);
            this.btnAusgabe.Name = "btnAusgabe";
            this.btnAusgabe.Size = new System.Drawing.Size(106, 39);
            this.btnAusgabe.TabIndex = 4;
            this.btnAusgabe.Text = "Ausgabe";
            this.btnAusgabe.UseVisualStyleBackColor = true;
            this.btnAusgabe.Click += new System.EventHandler(this.btnAusgabe_Click);
            // 
            // txtAusgabeZahl
            // 
            this.txtAusgabeZahl.Location = new System.Drawing.Point(72, 79);
            this.txtAusgabeZahl.Multiline = true;
            this.txtAusgabeZahl.Name = "txtAusgabeZahl";
            this.txtAusgabeZahl.ReadOnly = true;
            this.txtAusgabeZahl.Size = new System.Drawing.Size(100, 122);
            this.txtAusgabeZahl.TabIndex = 5;
            this.txtAusgabeZahl.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtAusgabeZahl);
            this.Controls.Add(this.btnAusgabe);
            this.Controls.Add(this.txtAusgabeMittelwert);
            this.Controls.Add(this.txtAusgabeSumme);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "02 Übung For-Schleife";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAusgabeSumme;
        private System.Windows.Forms.TextBox txtAusgabeMittelwert;
        private System.Windows.Forms.Button btnAusgabe;
        private System.Windows.Forms.TextBox txtAusgabeZahl;
    }
}

