﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _02_AA_ÜbungForSchleife
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAusgabe_Click(object sender, EventArgs e)
        {
           
            double summe = 0;
            int count = 0; //Zählt die Anzahl der Schleifendurchläufe
            double mittelwert = 0;

            txtAusgabeZahl.Text = ""; // Textfeld für die Ausgabe leeren

            //Schleifenkopf mit Startausdruck; Laufbedingung; Veränderung
            for ( double d = 35; d >= 20; d -= 2.5)
            {
                //Ausgabe der durch die Bedingungen im Schleifenkopf
                //erzeugten Werte in der Textbox
                txtAusgabeZahl.Text += d.ToString("0.00") + "\r\n";

                summe += d; //Bei jedem Schleifendurchlauf wird der neue Wert
                            //für d zur Summe hinzuaddiert summe = summe + d

                count += 1; //Bei jedem Schleifendurchlauf wird 1 addiert
                            //(count = count +1)
            }

            //Berechnung des Mittelwerts
            mittelwert = summe / count;

            //Ausgabe von Summe und Mittelwert
            txtAusgabeSumme.Text = "Summe: " + summe.ToString("0.00");
            txtAusgabeMittelwert.Text = "mittelwert: " + mittelwert.ToString("0.00");



        }
    }
}
