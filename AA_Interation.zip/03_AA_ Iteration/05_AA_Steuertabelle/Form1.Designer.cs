﻿namespace _05_AA_Steuertabelle
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAnzeige = new System.Windows.Forms.Label();
            this.btnAnzeige = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblAnzeige
            // 
            this.lblAnzeige.AutoSize = true;
            this.lblAnzeige.Location = new System.Drawing.Point(15, 20);
            this.lblAnzeige.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAnzeige.Name = "lblAnzeige";
            this.lblAnzeige.Size = new System.Drawing.Size(10, 13);
            this.lblAnzeige.TabIndex = 3;
            this.lblAnzeige.Text = "-";
            // 
            // btnAnzeige
            // 
            this.btnAnzeige.Location = new System.Drawing.Point(517, 20);
            this.btnAnzeige.Margin = new System.Windows.Forms.Padding(2);
            this.btnAnzeige.Name = "btnAnzeige";
            this.btnAnzeige.Size = new System.Drawing.Size(80, 35);
            this.btnAnzeige.TabIndex = 2;
            this.btnAnzeige.Text = "Anzeigen";
            this.btnAnzeige.UseVisualStyleBackColor = true;
            this.btnAnzeige.Click += new System.EventHandler(this.btnAnzeige_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(620, 450);
            this.Controls.Add(this.lblAnzeige);
            this.Controls.Add(this.btnAnzeige);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAnzeige;
        private System.Windows.Forms.Button btnAnzeige;
    }
}

