﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _05_AA_Steuertabelle
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAnzeige_Click(object sender, EventArgs e)
        {
            const int steuerSatzKleiner12T = 12;
            const int steuerSatzKleiner20T = 15;
            const int steuerSatzKleiner30T = 20;
            const int steuerSatzElse = 25;

            const int gehaltStart = 5000;
            const int gehaltEnde = 35000;
            const int gehaltStufe = 3000;

            const int gehaltGrenze12T = 12000;
            const int gehaltGrenze20T = 20000;
            const int gehaltGrenze30T = 30000;

            double gehalt;
            int steuerSatz;
            double steuerBetrag;
            double netto;

            lblAnzeige.Text = "";

            for (gehalt = gehaltStart; gehalt <= gehaltEnde; gehalt += gehaltStufe)
            {
                if (gehalt <= gehaltGrenze12T)
                    steuerSatz = steuerSatzKleiner12T;

                else if (gehalt <= gehaltGrenze20T)
                    steuerSatz = steuerSatzKleiner20T;

                else if (gehalt <= gehaltGrenze30T)
                    steuerSatz = steuerSatzKleiner30T;

                else steuerSatz = steuerSatzElse;

                steuerBetrag = gehalt * steuerSatz / 100;
                netto = gehalt - steuerBetrag;

                lblAnzeige.Text += gehalt + "€," + steuerSatzElse + "%," + steuerBetrag + "€," + netto + "€" + "\n";
            }
        }
    }
}
