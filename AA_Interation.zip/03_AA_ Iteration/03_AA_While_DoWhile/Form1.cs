﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _03_AA_While_DoWhile
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Zufallsvariable als globale Variable deklarieren
        //Der Variablen r wird ein Wert aus der Klasse Random 
        //später zugewiesen
        Random r = new Random();

        private void btnAusgabeWhile_Click(object sender, EventArgs e)
        {
            //Variablendeklaration
            int summe = 0;
            int zahl = 0;

            lblAusgabe.Text = "";

            //Die While-Schleife prüft die Bedingung vor
            //Ausführung der Anweisung
            //= kopfgesteuerte Schleife
            while (summe < 20)
            {
                zahl = r.Next(1, 7); //Zufallszahlen zwischen 1 und 6 
                                     //summe = summe + zahl;
                summe += zahl;

                lblAusgabe.Text += summe + "\n"; //Ausgabe aller Werte im Label
            }
        }

        private void btnAusgabeDoWhile_Click(object sender, EventArgs e)
        {
            //Variablendeklaration
            int summeDo = 0;
            int zahlDo = 0;

            lblAusgabe.Text = "";

            //Die While-Schleife prüft die Bedingung vor
            //Ausführung der Anweisung
            //= kopfgesteuerte Schleife
            do
            {
                zahlDo = r.Next(1, 7); //Zufallszahlen zwischen 1 und 6 
                                     //summe = summe + zahl;
                summeDo += zahlDo;

                lblAusgabe.Text += summeDo + "\n"; //Ausgabe aller Werte im Label
            }
            while (summeDo < 20);
            
        }
    }
}
