﻿namespace _03_AA_While_DoWhile
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAusgabe = new System.Windows.Forms.Label();
            this.btnAusgabeWhile = new System.Windows.Forms.Button();
            this.btnAusgabeDoWhile = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblAusgabe
            // 
            this.lblAusgabe.AutoSize = true;
            this.lblAusgabe.Location = new System.Drawing.Point(83, 39);
            this.lblAusgabe.Name = "lblAusgabe";
            this.lblAusgabe.Size = new System.Drawing.Size(10, 13);
            this.lblAusgabe.TabIndex = 0;
            this.lblAusgabe.Text = "-";
            // 
            // btnAusgabeWhile
            // 
            this.btnAusgabeWhile.Location = new System.Drawing.Point(196, 28);
            this.btnAusgabeWhile.Name = "btnAusgabeWhile";
            this.btnAusgabeWhile.Size = new System.Drawing.Size(100, 36);
            this.btnAusgabeWhile.TabIndex = 1;
            this.btnAusgabeWhile.Text = "while";
            this.btnAusgabeWhile.UseVisualStyleBackColor = true;
            this.btnAusgabeWhile.Click += new System.EventHandler(this.btnAusgabeWhile_Click);
            // 
            // btnAusgabeDoWhile
            // 
            this.btnAusgabeDoWhile.Location = new System.Drawing.Point(196, 87);
            this.btnAusgabeDoWhile.Name = "btnAusgabeDoWhile";
            this.btnAusgabeDoWhile.Size = new System.Drawing.Size(100, 38);
            this.btnAusgabeDoWhile.TabIndex = 2;
            this.btnAusgabeDoWhile.Text = "Do ... While";
            this.btnAusgabeDoWhile.UseVisualStyleBackColor = true;
            this.btnAusgabeDoWhile.Click += new System.EventHandler(this.btnAusgabeDoWhile_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnAusgabeDoWhile);
            this.Controls.Add(this.btnAusgabeWhile);
            this.Controls.Add(this.lblAusgabe);
            this.Name = "Form1";
            this.Text = "while / do ... while";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAusgabe;
        private System.Windows.Forms.Button btnAusgabeWhile;
        private System.Windows.Forms.Button btnAusgabeDoWhile;
    }
}

