﻿namespace _02_AA_Saison_1D
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbSaison = new System.Windows.Forms.ComboBox();
            this.btnPreise = new System.Windows.Forms.Button();
            this.txtAusgabePreise = new System.Windows.Forms.TextBox();
            this.txtEingabeTage = new System.Windows.Forms.TextBox();
            this.txtEingabePersonen = new System.Windows.Forms.TextBox();
            this.lblTage = new System.Windows.Forms.Label();
            this.lblPersonen = new System.Windows.Forms.Label();
            this.btnGesamtpreis = new System.Windows.Forms.Button();
            this.txtAusgabeNetto = new System.Windows.Forms.TextBox();
            this.txtAusgabeBrutto = new System.Windows.Forms.TextBox();
            this.lblNetto = new System.Windows.Forms.Label();
            this.lblBrutto = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmbSaison
            // 
            this.cmbSaison.FormattingEnabled = true;
            this.cmbSaison.Location = new System.Drawing.Point(42, 24);
            this.cmbSaison.Name = "cmbSaison";
            this.cmbSaison.Size = new System.Drawing.Size(129, 21);
            this.cmbSaison.TabIndex = 0;
            // 
            // btnPreise
            // 
            this.btnPreise.Location = new System.Drawing.Point(42, 56);
            this.btnPreise.Name = "btnPreise";
            this.btnPreise.Size = new System.Drawing.Size(129, 40);
            this.btnPreise.TabIndex = 1;
            this.btnPreise.Text = "Preise ausgeben";
            this.btnPreise.UseVisualStyleBackColor = true;
            this.btnPreise.Click += new System.EventHandler(this.btnPreise_Click);
            // 
            // txtAusgabePreise
            // 
            this.txtAusgabePreise.Location = new System.Drawing.Point(42, 123);
            this.txtAusgabePreise.Multiline = true;
            this.txtAusgabePreise.Name = "txtAusgabePreise";
            this.txtAusgabePreise.Size = new System.Drawing.Size(129, 103);
            this.txtAusgabePreise.TabIndex = 2;
            // 
            // txtEingabeTage
            // 
            this.txtEingabeTage.Location = new System.Drawing.Point(132, 19);
            this.txtEingabeTage.Name = "txtEingabeTage";
            this.txtEingabeTage.Size = new System.Drawing.Size(100, 20);
            this.txtEingabeTage.TabIndex = 3;
            // 
            // txtEingabePersonen
            // 
            this.txtEingabePersonen.Location = new System.Drawing.Point(132, 64);
            this.txtEingabePersonen.Name = "txtEingabePersonen";
            this.txtEingabePersonen.Size = new System.Drawing.Size(100, 20);
            this.txtEingabePersonen.TabIndex = 4;
            // 
            // lblTage
            // 
            this.lblTage.AutoSize = true;
            this.lblTage.Location = new System.Drawing.Point(31, 26);
            this.lblTage.Name = "lblTage";
            this.lblTage.Size = new System.Drawing.Size(67, 13);
            this.lblTage.TabIndex = 5;
            this.lblTage.Text = "Anzahl Tage";
            // 
            // lblPersonen
            // 
            this.lblPersonen.AutoSize = true;
            this.lblPersonen.Location = new System.Drawing.Point(31, 71);
            this.lblPersonen.Name = "lblPersonen";
            this.lblPersonen.Size = new System.Drawing.Size(87, 13);
            this.lblPersonen.TabIndex = 6;
            this.lblPersonen.Text = "Anzahl Personen";
            // 
            // btnGesamtpreis
            // 
            this.btnGesamtpreis.Location = new System.Drawing.Point(34, 127);
            this.btnGesamtpreis.Name = "btnGesamtpreis";
            this.btnGesamtpreis.Size = new System.Drawing.Size(198, 53);
            this.btnGesamtpreis.TabIndex = 7;
            this.btnGesamtpreis.Text = "Gesamtpreis berechnen";
            this.btnGesamtpreis.UseVisualStyleBackColor = true;
            this.btnGesamtpreis.Click += new System.EventHandler(this.btnGesamtpreis_Click);
            // 
            // txtAusgabeNetto
            // 
            this.txtAusgabeNetto.Location = new System.Drawing.Point(34, 221);
            this.txtAusgabeNetto.Name = "txtAusgabeNetto";
            this.txtAusgabeNetto.ReadOnly = true;
            this.txtAusgabeNetto.Size = new System.Drawing.Size(100, 20);
            this.txtAusgabeNetto.TabIndex = 8;
            // 
            // txtAusgabeBrutto
            // 
            this.txtAusgabeBrutto.Location = new System.Drawing.Point(34, 257);
            this.txtAusgabeBrutto.Name = "txtAusgabeBrutto";
            this.txtAusgabeBrutto.ReadOnly = true;
            this.txtAusgabeBrutto.Size = new System.Drawing.Size(100, 20);
            this.txtAusgabeBrutto.TabIndex = 9;
            // 
            // lblNetto
            // 
            this.lblNetto.AutoSize = true;
            this.lblNetto.Location = new System.Drawing.Point(197, 224);
            this.lblNetto.Name = "lblNetto";
            this.lblNetto.Size = new System.Drawing.Size(89, 13);
            this.lblNetto.TabIndex = 10;
            this.lblNetto.Text = "Nettogesamtpreis";
            // 
            // lblBrutto
            // 
            this.lblBrutto.AutoSize = true;
            this.lblBrutto.Location = new System.Drawing.Point(197, 264);
            this.lblBrutto.Name = "lblBrutto";
            this.lblBrutto.Size = new System.Drawing.Size(91, 13);
            this.lblBrutto.TabIndex = 11;
            this.lblBrutto.Text = "Bruttogesamtpreis";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cmbSaison);
            this.panel1.Controls.Add(this.btnPreise);
            this.panel1.Controls.Add(this.txtAusgabePreise);
            this.panel1.Location = new System.Drawing.Point(55, 62);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(209, 262);
            this.panel1.TabIndex = 12;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnGesamtpreis);
            this.panel2.Controls.Add(this.txtEingabeTage);
            this.panel2.Controls.Add(this.lblBrutto);
            this.panel2.Controls.Add(this.txtEingabePersonen);
            this.panel2.Controls.Add(this.lblNetto);
            this.panel2.Controls.Add(this.lblTage);
            this.panel2.Controls.Add(this.txtAusgabeBrutto);
            this.panel2.Controls.Add(this.lblPersonen);
            this.panel2.Controls.Add(this.txtAusgabeNetto);
            this.panel2.Location = new System.Drawing.Point(347, 41);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(311, 302);
            this.panel2.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(699, 450);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbSaison;
        private System.Windows.Forms.Button btnPreise;
        private System.Windows.Forms.TextBox txtAusgabePreise;
        private System.Windows.Forms.TextBox txtEingabeTage;
        private System.Windows.Forms.TextBox txtEingabePersonen;
        private System.Windows.Forms.Label lblTage;
        private System.Windows.Forms.Label lblPersonen;
        private System.Windows.Forms.Button btnGesamtpreis;
        private System.Windows.Forms.TextBox txtAusgabeNetto;
        private System.Windows.Forms.TextBox txtAusgabeBrutto;
        private System.Windows.Forms.Label lblNetto;
        private System.Windows.Forms.Label lblBrutto;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
    }
}

