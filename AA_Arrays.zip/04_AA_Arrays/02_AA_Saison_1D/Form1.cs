﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _02_AA_Saison_1D
{
    public partial class Form1 : Form
    {
        double[] saisonPreise = { 60, 70, 80, 65 };
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Werte zur Combobox hinzufügen ohne Array
            //cmbSaison.Items.Add("Frühling");
            //cmbSaison.Items.Add("Sommer");
            //cmbSaison.Items.Add("Herbst");
            //cmbSaison.Items.Add("Winter");

            //cmbSaison.SelectedIndex = 0;

            //Array mit Saisonnamen deklarieren
            string[] saisonName = { "Frühling", "Sommer", "Herbst", "Winter" };

            //Elemente des Array zur cmB hinzufügen
            cmbSaison.Items.AddRange(saisonName);

            //Vorauswahl des Wertes Frühling 
            cmbSaison.SelectedIndex = 0;
        }

        private void btnPreise_Click(object sender, EventArgs e)
        {
            //Ausgabe Textfeld leeren
            txtAusgabePreise.Clear();

            for (int i = 0; i < cmbSaison.Items.Count; i++)
            {
                //Elemente der cmB und Wert des Arrays am jeweils gleichen Index 
                //werden gemeinsam ausgeben
                txtAusgabePreise.Text += cmbSaison.Items[i] + "\t" +
                    saisonPreise[i].ToString("0.00 Euro") + "\r\n";
            }
        }

        private void btnGesamtpreis_Click(object sender, EventArgs e)
        {
            //Konstante 
            const double mwSTFaktor = 1.19;

            //Deklaration einer Variablen für die Speicherung des Preises
            //in Abhängigkeit von der getroffenen Saisonauswahl des Benutzers 
            //in der ComboBox steht "Frühling" am Index 0. im Preisarray steht der Preis
            //für Frühling ebenfalls am Index 0
            //Sommer jeweils Index 1, Herbst Index 2 und Winter Index 3

            //double[] saisonPreise = { 60, 70, 80, 65 };
            //string[] saisonName = { "Frühling", "Sommer", "Herbst", "Winter" };
            double preis = saisonPreise[cmbSaison.SelectedIndex];


            //Nutzereingaben konvertieren und in Variablen speichern
            int tage = Convert.ToInt16(txtEingabeTage.Text);
            int personen = Convert.ToInt16(txtEingabePersonen.Text);

            //Variablen für die Berechnung+
            double netto;
            double brutto;

            //Berechnung der Variablen
            netto = preis * tage * personen;
            brutto = netto * mwSTFaktor;

            //Ausgabe der berechneten Variablenwerte
            txtAusgabeNetto.Text = netto.ToString("0.00 Euro");
            txtAusgabeBrutto.Text = brutto.ToString("0.00 Euro");

        }
    }
}
