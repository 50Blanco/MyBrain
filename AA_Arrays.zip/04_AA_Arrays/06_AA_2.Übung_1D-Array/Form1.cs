﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _06_AA_2.Übung_1D_Array
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAuswertung_Click(object sender, EventArgs e)
        {
            int[] erwartung = { 10, 8, 9, 8, 4, 5, 11, 14, 8 };
            int[] ergebnis = { 13, 5, 6, 8, 5, 7, 11, 15, 10 };
            int[] schueler = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };


            for(int i = 0; i < schueler.Length; i++)
            {
                txtAusgabeErwTat.Text += "Schüler" + schueler[i] + "\t\t" + "Erwartung" + erwartung[i] + "\t"
                    + "Ergebnis" + ergebnis[i] + "\r\n";
            }

            txtAusgabeMaxErw.Text = erwartung.Max().ToString();
            txtAusgabeMinErw.Text = erwartung.Min().ToString();

            txtAusgabeMaxTat.Text = ergebnis.Max().ToString();
            txtAusgabeMinTat.Text = ergebnis.Min().ToString();


            int häufigAcht = 1;

            for(int i=0; i < erwartung.Length; i++)
            {
                if (erwartung[i] == 8)
                {
                    txtAusgabeAcht.Text = häufigAcht++.ToString();
                }
            }

            int häufigZehn = 1;

            for (int i = 0; i < ergebnis.Length; i++)
            {
                if (ergebnis[i] == 8)
                {
                    txtAusgabe10Tat.Text = häufigZehn++.ToString();
                }
            }

            int[] differenz = new int[9];
            for (int i = 0; i < erwartung.Length; i++)
            {
                differenz[i] = erwartung[i] - ergebnis[i];
                txtAusgabeAbweichung.Text += "Schueler" + schueler[i] + "\t\t" + differenz[i] + "\r\n";
            }

            int häufigMehrZwei = 1;
            for (int i = 0; i < differenz.Length; i++)
            {
                if (differenz[i] < -2)
                {
                    txtAusgabe2SchlechterTat.Text = häufigMehrZwei++.ToString();
                }
            }

            int häufigErwGleichTat = 1;
            for (int i = 0; i < differenz.Length; i++)
            {
                if (differenz[0] == 0)
                {
                    txtAusgabeErwGleichTat.Text = häufigErwGleichTat++.ToString();
                }
            }
        }
    }
}
