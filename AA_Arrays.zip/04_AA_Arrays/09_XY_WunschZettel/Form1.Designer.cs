﻿namespace _09_XY_WunschZettel
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblPreis = new System.Windows.Forms.Label();
            this.cmbProdukte = new System.Windows.Forms.ComboBox();
            this.rdBMustHave = new System.Windows.Forms.RadioButton();
            this.rdBNiceHave = new System.Windows.Forms.RadioButton();
            this.btnWarenkorb = new System.Windows.Forms.Button();
            this.txtAusgabeWarenkorb = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Auswahl";
            // 
            // lblPreis
            // 
            this.lblPreis.AutoSize = true;
            this.lblPreis.Location = new System.Drawing.Point(59, 107);
            this.lblPreis.Name = "lblPreis";
            this.lblPreis.Size = new System.Drawing.Size(202, 13);
            this.lblPreis.TabIndex = 1;
            this.lblPreis.Text = "Preis des ausgewählten Artikels anzeigen";
            // 
            // cmbProdukte
            // 
            this.cmbProdukte.FormattingEnabled = true;
            this.cmbProdukte.Location = new System.Drawing.Point(62, 61);
            this.cmbProdukte.Name = "cmbProdukte";
            this.cmbProdukte.Size = new System.Drawing.Size(121, 21);
            this.cmbProdukte.TabIndex = 2;
            this.cmbProdukte.SelectedIndexChanged += new System.EventHandler(this.cmbProdukte_SelectedIndexChanged);
            // 
            // rdBMustHave
            // 
            this.rdBMustHave.AutoSize = true;
            this.rdBMustHave.Checked = true;
            this.rdBMustHave.Location = new System.Drawing.Point(62, 154);
            this.rdBMustHave.Name = "rdBMustHave";
            this.rdBMustHave.Size = new System.Drawing.Size(94, 17);
            this.rdBMustHave.TabIndex = 3;
            this.rdBMustHave.TabStop = true;
            this.rdBMustHave.Text = "\"Must have!!!\"";
            this.rdBMustHave.UseVisualStyleBackColor = true;
            // 
            // rdBNiceHave
            // 
            this.rdBNiceHave.AutoSize = true;
            this.rdBNiceHave.Location = new System.Drawing.Point(176, 154);
            this.rdBNiceHave.Name = "rdBNiceHave";
            this.rdBNiceHave.Size = new System.Drawing.Size(99, 17);
            this.rdBNiceHave.TabIndex = 4;
            this.rdBNiceHave.TabStop = true;
            this.rdBNiceHave.Text = "\"Nice to have!\"";
            this.rdBNiceHave.UseVisualStyleBackColor = true;
            // 
            // btnWarenkorb
            // 
            this.btnWarenkorb.Location = new System.Drawing.Point(62, 206);
            this.btnWarenkorb.Name = "btnWarenkorb";
            this.btnWarenkorb.Size = new System.Drawing.Size(256, 38);
            this.btnWarenkorb.TabIndex = 5;
            this.btnWarenkorb.Text = "Zum Warenkorb hinzufügen/Warenkorb anzeigen";
            this.btnWarenkorb.UseVisualStyleBackColor = true;
            this.btnWarenkorb.Click += new System.EventHandler(this.btnWarenkorb_Click);
            // 
            // txtAusgabeWarenkorb
            // 
            this.txtAusgabeWarenkorb.Location = new System.Drawing.Point(62, 270);
            this.txtAusgabeWarenkorb.Multiline = true;
            this.txtAusgabeWarenkorb.Name = "txtAusgabeWarenkorb";
            this.txtAusgabeWarenkorb.ReadOnly = true;
            this.txtAusgabeWarenkorb.Size = new System.Drawing.Size(256, 96);
            this.txtAusgabeWarenkorb.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(497, 458);
            this.Controls.Add(this.txtAusgabeWarenkorb);
            this.Controls.Add(this.btnWarenkorb);
            this.Controls.Add(this.rdBNiceHave);
            this.Controls.Add(this.rdBMustHave);
            this.Controls.Add(this.cmbProdukte);
            this.Controls.Add(this.lblPreis);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblPreis;
        private System.Windows.Forms.ComboBox cmbProdukte;
        private System.Windows.Forms.RadioButton rdBMustHave;
        private System.Windows.Forms.RadioButton rdBNiceHave;
        private System.Windows.Forms.Button btnWarenkorb;
        private System.Windows.Forms.TextBox txtAusgabeWarenkorb;
    }
}

