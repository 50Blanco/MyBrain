﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _09_XY_WunschZettel
{
    public partial class Form1 : Form
    {
        double[] preis = { 210.00, 49.90, 39.80, 179.00, 139.00, 57.70 };

        string[] wunsch = new string[4];
        string[] dringlichkeit = new string[4];
        int i; 
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] produkt = { "Espressomaschine", "MarioKart", "Kuscheldecke", "AirPods", "Soundbar", "Handyhülle" };
            cmbProdukte.Items.AddRange(produkt);
            cmbProdukte.SelectedIndex = 3;

        }
        private void cmbProdukte_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblPreis.Text = preis[cmbProdukte.SelectedIndex].ToString("0.00 Euro");

            //double ausgabeArtikel = preis[cmbProdukte.SelectedIndex];
            //llbPreis.Text = ausgabeArtikel.ToString("0.00 Euro");
                
        }
        private void btnWarenkorb_Click(object sender, EventArgs e)
        {
            string mustHave = rdBMustHave.ToString();
            string niceToHave = rdBNiceHave.ToString();

            if (i < wunsch.Length)
            {
                wunsch[i] = cmbProdukte.SelectedItem.ToString();
                dringlichkeit[i] = niceToHave;
                i++;
            }
            else
            {
                MessageBox.Show("Maximal 4 Werte möglich!");
            }

            txtAusgabeWarenkorb.Text = 


            //string produkt = cmbProdukte.SelectedItem.ToString();

            //if (rdBMustHave.Checked)
            //{
            //    produkt += "Must Have";
            //}
            //else
            //{
            //    produkt += "nice to have";
            //}
            



        }
    }
}
