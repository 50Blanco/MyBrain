﻿namespace _07_AA_Tickets
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAnzahl = new System.Windows.Forms.Label();
            this.lblKategorie = new System.Windows.Forms.Label();
            this.lblZahlungsmethode = new System.Windows.Forms.Label();
            this.cmbAnzahl = new System.Windows.Forms.ComboBox();
            this.cmbKategorie = new System.Windows.Forms.ComboBox();
            this.cmbZahlungsmethode = new System.Windows.Forms.ComboBox();
            this.chkBSchüler = new System.Windows.Forms.CheckBox();
            this.btnBerechnen = new System.Windows.Forms.Button();
            this.lblGesamtpreis = new System.Windows.Forms.Label();
            this.txtAusgabeGesamtpreis = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblAnzahl
            // 
            this.lblAnzahl.AutoSize = true;
            this.lblAnzahl.Location = new System.Drawing.Point(71, 38);
            this.lblAnzahl.Name = "lblAnzahl";
            this.lblAnzahl.Size = new System.Drawing.Size(39, 13);
            this.lblAnzahl.TabIndex = 0;
            this.lblAnzahl.Text = "Anzahl";
            // 
            // lblKategorie
            // 
            this.lblKategorie.AutoSize = true;
            this.lblKategorie.Location = new System.Drawing.Point(71, 91);
            this.lblKategorie.Name = "lblKategorie";
            this.lblKategorie.Size = new System.Drawing.Size(52, 13);
            this.lblKategorie.TabIndex = 1;
            this.lblKategorie.Text = "Kategorie";
            // 
            // lblZahlungsmethode
            // 
            this.lblZahlungsmethode.AutoSize = true;
            this.lblZahlungsmethode.Location = new System.Drawing.Point(71, 152);
            this.lblZahlungsmethode.Name = "lblZahlungsmethode";
            this.lblZahlungsmethode.Size = new System.Drawing.Size(92, 13);
            this.lblZahlungsmethode.TabIndex = 2;
            this.lblZahlungsmethode.Text = "Zahlungsmethode";
            // 
            // cmbAnzahl
            // 
            this.cmbAnzahl.FormattingEnabled = true;
            this.cmbAnzahl.Location = new System.Drawing.Point(74, 61);
            this.cmbAnzahl.Name = "cmbAnzahl";
            this.cmbAnzahl.Size = new System.Drawing.Size(121, 21);
            this.cmbAnzahl.TabIndex = 3;
            // 
            // cmbKategorie
            // 
            this.cmbKategorie.FormattingEnabled = true;
            this.cmbKategorie.Location = new System.Drawing.Point(74, 118);
            this.cmbKategorie.Name = "cmbKategorie";
            this.cmbKategorie.Size = new System.Drawing.Size(121, 21);
            this.cmbKategorie.TabIndex = 4;
            // 
            // cmbZahlungsmethode
            // 
            this.cmbZahlungsmethode.FormattingEnabled = true;
            this.cmbZahlungsmethode.Location = new System.Drawing.Point(74, 177);
            this.cmbZahlungsmethode.Name = "cmbZahlungsmethode";
            this.cmbZahlungsmethode.Size = new System.Drawing.Size(121, 21);
            this.cmbZahlungsmethode.TabIndex = 5;
            // 
            // chkBSchüler
            // 
            this.chkBSchüler.AutoSize = true;
            this.chkBSchüler.Location = new System.Drawing.Point(74, 229);
            this.chkBSchüler.Name = "chkBSchüler";
            this.chkBSchüler.Size = new System.Drawing.Size(145, 17);
            this.chkBSchüler.TabIndex = 6;
            this.chkBSchüler.Text = "Ich bin Schüler / Student";
            this.chkBSchüler.UseVisualStyleBackColor = true;
            // 
            // btnBerechnen
            // 
            this.btnBerechnen.Location = new System.Drawing.Point(74, 280);
            this.btnBerechnen.Name = "btnBerechnen";
            this.btnBerechnen.Size = new System.Drawing.Size(121, 36);
            this.btnBerechnen.TabIndex = 7;
            this.btnBerechnen.Text = "zu zahlender Preis";
            this.btnBerechnen.UseVisualStyleBackColor = true;
            this.btnBerechnen.Click += new System.EventHandler(this.btnBerechnen_Click);
            // 
            // lblGesamtpreis
            // 
            this.lblGesamtpreis.AutoSize = true;
            this.lblGesamtpreis.Location = new System.Drawing.Point(74, 343);
            this.lblGesamtpreis.Name = "lblGesamtpreis";
            this.lblGesamtpreis.Size = new System.Drawing.Size(65, 13);
            this.lblGesamtpreis.TabIndex = 8;
            this.lblGesamtpreis.Text = "Gesamtpreis";
            // 
            // txtAusgabeGesamtpreis
            // 
            this.txtAusgabeGesamtpreis.Location = new System.Drawing.Point(74, 378);
            this.txtAusgabeGesamtpreis.Name = "txtAusgabeGesamtpreis";
            this.txtAusgabeGesamtpreis.ReadOnly = true;
            this.txtAusgabeGesamtpreis.Size = new System.Drawing.Size(121, 20);
            this.txtAusgabeGesamtpreis.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtAusgabeGesamtpreis);
            this.Controls.Add(this.lblGesamtpreis);
            this.Controls.Add(this.btnBerechnen);
            this.Controls.Add(this.chkBSchüler);
            this.Controls.Add(this.cmbZahlungsmethode);
            this.Controls.Add(this.cmbKategorie);
            this.Controls.Add(this.cmbAnzahl);
            this.Controls.Add(this.lblZahlungsmethode);
            this.Controls.Add(this.lblKategorie);
            this.Controls.Add(this.lblAnzahl);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAnzahl;
        private System.Windows.Forms.Label lblKategorie;
        private System.Windows.Forms.Label lblZahlungsmethode;
        private System.Windows.Forms.ComboBox cmbAnzahl;
        private System.Windows.Forms.ComboBox cmbKategorie;
        private System.Windows.Forms.ComboBox cmbZahlungsmethode;
        private System.Windows.Forms.CheckBox chkBSchüler;
        private System.Windows.Forms.Button btnBerechnen;
        private System.Windows.Forms.Label lblGesamtpreis;
        private System.Windows.Forms.TextBox txtAusgabeGesamtpreis;
    }
}

