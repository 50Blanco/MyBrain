﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _07_AA_Tickets
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] anzahlCombo = { "1", "2", "3", "4", "5" };
            cmbAnzahl.Items.AddRange(anzahlCombo);
            cmbAnzahl.SelectedIndex = 0;

            string[] kategorieCombo = { "A", "B", "C", "D" };
            cmbKategorie.Items.AddRange(kategorieCombo);
            cmbKategorie.SelectedIndex = 0;

            string[] zahlungsMethodeCombo = { "Vorkasse", "PayPal", "Rechnung" };
            cmbZahlungsmethode.Items.AddRange(zahlungsMethodeCombo);
            cmbZahlungsmethode.SelectedIndex = 0;
        }

        private void btnBerechnen_Click(object sender, EventArgs e)
        {
            int[] anzahl = { 1, 2, 3, 4, 5 };
            double[] preisKategorie = { 130, 110, 80, 50 };
            double[] zahlungsMethode = { 0.95, 1, 1.1 };

            const double studRabatt = 0.5;
            double gesamtPreis = 0;

            gesamtPreis = anzahl[cmbAnzahl.SelectedIndex] *
                          preisKategorie[cmbKategorie.SelectedIndex] * 
                          zahlungsMethode[cmbZahlungsmethode.SelectedIndex];

            if (chkBSchüler.Checked)
            {
                gesamtPreis *= studRabatt; //gesamtpreis = gesamtpreis * studRabatt;
            }

            txtAusgabeGesamtpreis.Text = gesamtPreis.ToString("0.00 Euro");
        }
    }
}
