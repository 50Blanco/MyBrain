﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _01_AA_Grundlagen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Arrays speichern eine festgelegte Anzahl von Elementen des gleichen Datentyps.
        //Sie sind somit eine Sammlung von Variablen des gleichen Typs,
        //deren Speicherorte aufeinander folgenden.

        //Deklaration von Arrays
        //datenTyp[] arrayName;

        //initialisieren eines Arrays
        //datenTyp[] arrayName = new datenTyp[anzahlEinträge];

        //Beispiel Noten von 19 Schüler erfassen
        //int[] noten = new int [19];

        //Werte dem Array zuweisen:
        //arrayName[index] = wert;

        //Beispiel:
        //noten[0] = 13;
        //noten[1] = 10;
        //noten[2] = 8;
        //noten[3] = 5;
        //noten[18] = 11;
        //...

        //Alternativ: (Variante 2)
        //int[] noten = {13, 10, 8, 5, ..., 11};
        //------------------------------------------------------------------




        //Aufgabe 1
        private void btnAusgabe1_Click(object sender, EventArgs e)
        {
            //Variante 2:
            int[] euro = new int[] { 10, 15, 20, 25 };
            txtAusgabe.Text = euro[2].ToString("0.00 Euro");
        }

        //Aufgabe 2
        private void btnAusgabe2_Click(object sender, EventArgs e)
        {
            try
            {
               
                int[] euro = { 10, 15, 20, 25 };
                euro[0] = Convert.ToInt16(txtEingabe.Text);
                txtAusgabe.Text = euro[0].ToString("0.00 Euro");
            }
            catch
            {
                MessageBox.Show("Bitte geben Sie einen Wert ein!");
            }
            
        }

        private void btnAusgabe3_Click(object sender, EventArgs e)
        {
            int[] euro = { 10, 15, 20, 25 };
            txtAusgabe.Text = euro.Length.ToString("0 Arrays vorhanden");
        }



        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnAusgabe4_Click(object sender, EventArgs e)
        {
            int[] euro = { 10, 15, 20, 25 };
            txtAusgabe.Text = "";

            foreach (int zahl in euro)
            {
                txtAusgabe.Text += zahl.ToString("0.00 \r\n");
            }

            //Alternativ:
            //int[] euro = { 10, 15, 20, 25};
            //for (int i = 0; i < euro.Length; i++)
            //{
            //txtAusgabe.Text += euro[i] + "\r\n";
            //}
        }
    }
}
