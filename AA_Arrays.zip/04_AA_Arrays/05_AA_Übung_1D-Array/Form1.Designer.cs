﻿namespace _05_AA_Übung_1D_Array
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAusgabe = new System.Windows.Forms.Label();
            this.btnAnzeigen3 = new System.Windows.Forms.Button();
            this.btnAnzeigen2 = new System.Windows.Forms.Button();
            this.btnAnzeigen1 = new System.Windows.Forms.Button();
            this.lstFeld = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lblAusgabe
            // 
            this.lblAusgabe.AutoSize = true;
            this.lblAusgabe.Location = new System.Drawing.Point(251, 217);
            this.lblAusgabe.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAusgabe.Name = "lblAusgabe";
            this.lblAusgabe.Size = new System.Drawing.Size(19, 13);
            this.lblAusgabe.TabIndex = 9;
            this.lblAusgabe.Text = "__";
            // 
            // btnAnzeigen3
            // 
            this.btnAnzeigen3.Location = new System.Drawing.Point(308, 102);
            this.btnAnzeigen3.Margin = new System.Windows.Forms.Padding(2);
            this.btnAnzeigen3.Name = "btnAnzeigen3";
            this.btnAnzeigen3.Size = new System.Drawing.Size(88, 31);
            this.btnAnzeigen3.TabIndex = 8;
            this.btnAnzeigen3.Text = "Anzeigen 3";
            this.btnAnzeigen3.UseVisualStyleBackColor = true;
            this.btnAnzeigen3.Click += new System.EventHandler(this.btnAnzeigen3_Click);
            // 
            // btnAnzeigen2
            // 
            this.btnAnzeigen2.Location = new System.Drawing.Point(308, 67);
            this.btnAnzeigen2.Margin = new System.Windows.Forms.Padding(2);
            this.btnAnzeigen2.Name = "btnAnzeigen2";
            this.btnAnzeigen2.Size = new System.Drawing.Size(88, 31);
            this.btnAnzeigen2.TabIndex = 7;
            this.btnAnzeigen2.Text = "Anzeigen 2";
            this.btnAnzeigen2.UseVisualStyleBackColor = true;
            this.btnAnzeigen2.Click += new System.EventHandler(this.btnAnzeigen2_Click);
            // 
            // btnAnzeigen1
            // 
            this.btnAnzeigen1.Location = new System.Drawing.Point(308, 33);
            this.btnAnzeigen1.Margin = new System.Windows.Forms.Padding(2);
            this.btnAnzeigen1.Name = "btnAnzeigen1";
            this.btnAnzeigen1.Size = new System.Drawing.Size(88, 31);
            this.btnAnzeigen1.TabIndex = 6;
            this.btnAnzeigen1.Text = "Anzeigen 1";
            this.btnAnzeigen1.UseVisualStyleBackColor = true;
            this.btnAnzeigen1.Click += new System.EventHandler(this.btnAnzeigen1_Click);
            // 
            // lstFeld
            // 
            this.lstFeld.FormattingEnabled = true;
            this.lstFeld.Location = new System.Drawing.Point(42, 33);
            this.lstFeld.Margin = new System.Windows.Forms.Padding(2);
            this.lstFeld.Name = "lstFeld";
            this.lstFeld.Size = new System.Drawing.Size(158, 199);
            this.lstFeld.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblAusgabe);
            this.Controls.Add(this.btnAnzeigen3);
            this.Controls.Add(this.btnAnzeigen2);
            this.Controls.Add(this.btnAnzeigen1);
            this.Controls.Add(this.lstFeld);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAusgabe;
        private System.Windows.Forms.Button btnAnzeigen3;
        private System.Windows.Forms.Button btnAnzeigen2;
        private System.Windows.Forms.Button btnAnzeigen1;
        private System.Windows.Forms.ListBox lstFeld;
    }
}

