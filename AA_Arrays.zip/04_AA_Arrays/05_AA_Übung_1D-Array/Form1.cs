﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _05_AA_Übung_1D_Array
{
    public partial class Form1 : Form
    {
        //gloale Dekleration der Variablen r der Klasse random
        //Random r = new random();
        Random r = new Random();
        int[] a = new int[7];
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnAnzeigen1_Click(object sender, EventArgs e)
        {
            //int[] a = new int [7]; global deklariert
            lstFeld.Items.Clear();

            for (int i = 0; i < a.Length; i++)
            {
                a[i] = r.Next(20, 31);
                lstFeld.Items.Add(a[i]);
            }
        }

        private void btnAnzeigen2_Click(object sender, EventArgs e)
        {
            //int[] a = new int[7];
            int maxWert;
            int minWert;
            int maxWertIndex;
            int minWertIndex;

            //lstFeld.Items.Clear();
            //for (int i = 0; i < a.Length; i++)
            //{
            //    a[i] = r.Next(20, 31);
            //    lstFeld.Items.Add(a[i]);
            //}

            //Max/Min initialisieren
            maxWert = a[0];
            minWert = a[0];
            maxWertIndex = 0;
            minWertIndex = 0;

            //Max/Min suchen
            for (int i = 1; i < a.Length; i++)
            {
                if (a[i] > maxWert)
                {
                    maxWert = a[i];
                    maxWertIndex = i;
                }

                if (a[i] < minWert)
                {
                    minWert = a[i];
                    minWertIndex = i;
                }
            }

            //lblAusgabe.Text = a.Max().ToString();
            //Max/Min
            lblAusgabe.Text = "Max. Wert: " + maxWert + " bei Index " + maxWertIndex + "\n" +
                "Min. Wert: " + minWert + " bei Index " + minWertIndex;


        }

        private void btnAnzeigen3_Click(object sender, EventArgs e)
        {
            //int[] a = new int[]; (wurde oben schon global deklariert)
            int[] b = new int[7];
            int suchIndex;

            for (int i = 0; i < a.Length; i++)
            {
                a[i] = r.Next(20, 31);
            }

            //Duplikat von Array a erstellen
            b = (int[])a.Clone();

            //Array sortieren
            Array.Sort(b);

            lstFeld.Items.Clear();

            for(int i = 0; i < a.Length; i++)
            {

                lstFeld.Items.Add(b[i]);
            }

            //Index vom Wert 25 suchen
            suchIndex = Array.IndexOf(b, 25);

            if (suchIndex == -1)
            {
                lblAusgabe.Text = "Gesuchter Wert 25 ist nicht vorhanden!";
            }

            else
            {
                lblAusgabe.Text = "Gesuchter Wert 25 ist bei Index: " + suchIndex;
            }
        }
    }
}
