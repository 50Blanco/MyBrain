﻿namespace _04_AA_S52A2
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblWarengruppe = new System.Windows.Forms.Label();
            this.cmBWarengruppe = new System.Windows.Forms.ComboBox();
            this.lblKosten = new System.Windows.Forms.Label();
            this.txtAusgabeKosten = new System.Windows.Forms.TextBox();
            this.btnBerechnen = new System.Windows.Forms.Button();
            this.txtAusgabeKostenListe = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblWarengruppe
            // 
            this.lblWarengruppe.AutoSize = true;
            this.lblWarengruppe.Location = new System.Drawing.Point(167, 41);
            this.lblWarengruppe.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWarengruppe.Name = "lblWarengruppe";
            this.lblWarengruppe.Size = new System.Drawing.Size(90, 16);
            this.lblWarengruppe.TabIndex = 0;
            this.lblWarengruppe.Text = "Warengruppe";
            // 
            // cmBWarengruppe
            // 
            this.cmBWarengruppe.FormattingEnabled = true;
            this.cmBWarengruppe.Location = new System.Drawing.Point(171, 95);
            this.cmBWarengruppe.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmBWarengruppe.Name = "cmBWarengruppe";
            this.cmBWarengruppe.Size = new System.Drawing.Size(160, 24);
            this.cmBWarengruppe.TabIndex = 1;
            // 
            // lblKosten
            // 
            this.lblKosten.AutoSize = true;
            this.lblKosten.Location = new System.Drawing.Point(167, 166);
            this.lblKosten.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblKosten.Name = "lblKosten";
            this.lblKosten.Size = new System.Drawing.Size(179, 16);
            this.lblKosten.TabIndex = 2;
            this.lblKosten.Text = "Die Versandkosten betragen";
            // 
            // txtAusgabeKosten
            // 
            this.txtAusgabeKosten.Location = new System.Drawing.Point(171, 223);
            this.txtAusgabeKosten.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtAusgabeKosten.Name = "txtAusgabeKosten";
            this.txtAusgabeKosten.Size = new System.Drawing.Size(484, 22);
            this.txtAusgabeKosten.TabIndex = 3;
            // 
            // btnBerechnen
            // 
            this.btnBerechnen.Location = new System.Drawing.Point(171, 286);
            this.btnBerechnen.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnBerechnen.Name = "btnBerechnen";
            this.btnBerechnen.Size = new System.Drawing.Size(256, 57);
            this.btnBerechnen.TabIndex = 4;
            this.btnBerechnen.Text = "Versankosten für alle Warengruppen angeben";
            this.btnBerechnen.UseVisualStyleBackColor = true;
            this.btnBerechnen.Click += new System.EventHandler(this.btnBerechnen_Click);
            // 
            // txtAusgabeKostenListe
            // 
            this.txtAusgabeKostenListe.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtAusgabeKostenListe.Location = new System.Drawing.Point(171, 366);
            this.txtAusgabeKostenListe.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtAusgabeKostenListe.Multiline = true;
            this.txtAusgabeKostenListe.Name = "txtAusgabeKostenListe";
            this.txtAusgabeKostenListe.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtAusgabeKostenListe.Size = new System.Drawing.Size(255, 173);
            this.txtAusgabeKostenListe.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 568);
            this.Controls.Add(this.txtAusgabeKostenListe);
            this.Controls.Add(this.btnBerechnen);
            this.Controls.Add(this.txtAusgabeKosten);
            this.Controls.Add(this.lblKosten);
            this.Controls.Add(this.cmBWarengruppe);
            this.Controls.Add(this.lblWarengruppe);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWarengruppe;
        private System.Windows.Forms.ComboBox cmBWarengruppe;
        private System.Windows.Forms.Label lblKosten;
        private System.Windows.Forms.TextBox txtAusgabeKosten;
        private System.Windows.Forms.Button btnBerechnen;
        private System.Windows.Forms.TextBox txtAusgabeKostenListe;
    }
}

