﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _04_AA_S52A2
{
    public partial class Form1 : Form
    {
        double[] versandkosten = { 1.75, 1.75, 1.50, 1.60, 2.00, 3.00, 2.50, 3.00, 4.50, 5.00 };
        public Form1()
        {
            InitializeComponent();
        }

        private void btnBerechnen_Click(object sender, EventArgs e)
        {
            string versandkostenEinzel = versandkosten[cmBWarengruppe.SelectedIndex].ToString("0.00 Euro");
            string warenGruppe = cmBWarengruppe.SelectedItem.ToString();


            //Alternativ könnte ich auch "cmBWarengruppe.SelectedItem" einfügen, statt "warenGruppe" zu deklarieren
            txtAusgabeKosten.Text = ("Die Versanskosten für die Warengruppe " + warenGruppe + " betragen " + versandkostenEinzel);

            //Textfeld leeren
            txtAusgabeKostenListe.Clear();

            for (int i = 0; i < cmBWarengruppe.Items.Count; i++)
            {
                txtAusgabeKostenListe.Text += cmBWarengruppe.Items[i] + "\t" +
                    versandkosten[i].ToString("0.00 Euro") + "\r\n";
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Array mit warenGruppe deklarieren
            string[] warenGruppe = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", };

            //Elemente des Array zur cmB hinzufügen
            cmBWarengruppe.Items.AddRange(warenGruppe);

            //Vorauswahl des Wertes "1"
            cmBWarengruppe.SelectedIndex = 0;
        }
    }
}
