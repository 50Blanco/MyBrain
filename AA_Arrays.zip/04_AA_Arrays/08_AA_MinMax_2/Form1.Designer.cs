﻿namespace _08_AA_MinMax_2
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtEingabeButter = new System.Windows.Forms.TextBox();
            this.txtEingabeMehl = new System.Windows.Forms.TextBox();
            this.txtEingabeNudeln = new System.Windows.Forms.TextBox();
            this.txtEingabeZucker = new System.Windows.Forms.TextBox();
            this.txtEingabeTomaten = new System.Windows.Forms.TextBox();
            this.txtEingabeSalat = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblAnzahl = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtEingabeGesamt = new System.Windows.Forms.TextBox();
            this.txtEingabeMaxAnzahl = new System.Windows.Forms.TextBox();
            this.txtEingabeMinAnzahl = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtEingabeButter
            // 
            this.txtEingabeButter.Location = new System.Drawing.Point(211, 52);
            this.txtEingabeButter.Name = "txtEingabeButter";
            this.txtEingabeButter.Size = new System.Drawing.Size(51, 20);
            this.txtEingabeButter.TabIndex = 0;
            // 
            // txtEingabeMehl
            // 
            this.txtEingabeMehl.Location = new System.Drawing.Point(211, 78);
            this.txtEingabeMehl.Name = "txtEingabeMehl";
            this.txtEingabeMehl.Size = new System.Drawing.Size(51, 20);
            this.txtEingabeMehl.TabIndex = 1;
            // 
            // txtEingabeNudeln
            // 
            this.txtEingabeNudeln.Location = new System.Drawing.Point(211, 133);
            this.txtEingabeNudeln.Name = "txtEingabeNudeln";
            this.txtEingabeNudeln.Size = new System.Drawing.Size(51, 20);
            this.txtEingabeNudeln.TabIndex = 3;
            // 
            // txtEingabeZucker
            // 
            this.txtEingabeZucker.Location = new System.Drawing.Point(211, 104);
            this.txtEingabeZucker.Name = "txtEingabeZucker";
            this.txtEingabeZucker.Size = new System.Drawing.Size(51, 20);
            this.txtEingabeZucker.TabIndex = 2;
            // 
            // txtEingabeTomaten
            // 
            this.txtEingabeTomaten.Location = new System.Drawing.Point(211, 190);
            this.txtEingabeTomaten.Name = "txtEingabeTomaten";
            this.txtEingabeTomaten.Size = new System.Drawing.Size(51, 20);
            this.txtEingabeTomaten.TabIndex = 5;
            // 
            // txtEingabeSalat
            // 
            this.txtEingabeSalat.Location = new System.Drawing.Point(211, 164);
            this.txtEingabeSalat.Name = "txtEingabeSalat";
            this.txtEingabeSalat.Size = new System.Drawing.Size(51, 20);
            this.txtEingabeSalat.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(97, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Butter";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(97, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Mehl";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(97, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Zucker";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(97, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Nudeln";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(97, 171);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Salat";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(97, 197);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Tomaten";
            // 
            // lblAnzahl
            // 
            this.lblAnzahl.AutoSize = true;
            this.lblAnzahl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnzahl.Location = new System.Drawing.Point(213, 24);
            this.lblAnzahl.Name = "lblAnzahl";
            this.lblAnzahl.Size = new System.Drawing.Size(45, 13);
            this.lblAnzahl.TabIndex = 12;
            this.lblAnzahl.Text = "Anzahl";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(100, 244);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(155, 37);
            this.button1.TabIndex = 13;
            this.button1.Text = "Anzeige Min., Max. und Gesamtanzahl";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(97, 367);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Gesamt:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(97, 341);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 13);
            this.label9.TabIndex = 15;
            this.label9.Text = "Max Anzahl";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(97, 310);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 13);
            this.label10.TabIndex = 14;
            this.label10.Text = "Min Anzahl";
            // 
            // txtEingabeGesamt
            // 
            this.txtEingabeGesamt.Location = new System.Drawing.Point(204, 360);
            this.txtEingabeGesamt.Name = "txtEingabeGesamt";
            this.txtEingabeGesamt.Size = new System.Drawing.Size(51, 20);
            this.txtEingabeGesamt.TabIndex = 19;
            // 
            // txtEingabeMaxAnzahl
            // 
            this.txtEingabeMaxAnzahl.Location = new System.Drawing.Point(204, 334);
            this.txtEingabeMaxAnzahl.Name = "txtEingabeMaxAnzahl";
            this.txtEingabeMaxAnzahl.Size = new System.Drawing.Size(51, 20);
            this.txtEingabeMaxAnzahl.TabIndex = 18;
            // 
            // txtEingabeMinAnzahl
            // 
            this.txtEingabeMinAnzahl.Location = new System.Drawing.Point(204, 303);
            this.txtEingabeMinAnzahl.Name = "txtEingabeMinAnzahl";
            this.txtEingabeMinAnzahl.Size = new System.Drawing.Size(51, 20);
            this.txtEingabeMinAnzahl.TabIndex = 17;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtEingabeGesamt);
            this.Controls.Add(this.txtEingabeMaxAnzahl);
            this.Controls.Add(this.txtEingabeMinAnzahl);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblAnzahl);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtEingabeTomaten);
            this.Controls.Add(this.txtEingabeSalat);
            this.Controls.Add(this.txtEingabeNudeln);
            this.Controls.Add(this.txtEingabeZucker);
            this.Controls.Add(this.txtEingabeMehl);
            this.Controls.Add(this.txtEingabeButter);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtEingabeButter;
        private System.Windows.Forms.TextBox txtEingabeMehl;
        private System.Windows.Forms.TextBox txtEingabeNudeln;
        private System.Windows.Forms.TextBox txtEingabeZucker;
        private System.Windows.Forms.TextBox txtEingabeTomaten;
        private System.Windows.Forms.TextBox txtEingabeSalat;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblAnzahl;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtEingabeGesamt;
        private System.Windows.Forms.TextBox txtEingabeMaxAnzahl;
        private System.Windows.Forms.TextBox txtEingabeMinAnzahl;
    }
}

