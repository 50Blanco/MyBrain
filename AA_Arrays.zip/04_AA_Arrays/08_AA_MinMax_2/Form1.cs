﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _08_AA_MinMax_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
            int[] anzahl = {
                Convert.ToInt16(txtEingabeButter.Text),
                Convert.ToInt32(txtEingabeNudeln.Text),
                Convert.ToInt32(txtEingabeSalat.Text),
                Convert.ToInt32(txtEingabeTomaten.Text),
                Convert.ToInt32(txtEingabeZucker.Text),
                Convert.ToInt32(txtEingabeMehl.Text) };

            int minAnzahl = anzahl[0];
            int maxAnzahl = anzahl[0];
            int gesamtAnzahl = 0;


                //for (int i = 0; i < anzahl.Length; i++)
                //{ 
                //if (max < anzahl[i])
                //    max = anzahl[i];
                // if (min > anzahl[i])
                //     min = anzahl[i];
                // summe += anzahl[i];
                //}

                //Version 2:
                //txtMax.Text = anzahl.Max().ToString();
                //txtMin.Text = anzahl.Min().ToString();
                //txtGesamt.Text = anzahl.Sum().ToString();

                minAnzahl = anzahl.Min();
            for (int i = 1; i < anzahl.Length; i++)
            {
                if (anzahl[i] > maxAnzahl)
                {
                    maxAnzahl = anzahl[i];
                }
            }

            foreach(var zahl in anzahl)
            {
                gesamtAnzahl += zahl;
            }

                txtEingabeMinAnzahl.Text = minAnzahl.ToString();
                txtEingabeMaxAnzahl.Text = maxAnzahl.ToString();
                txtEingabeGesamt.Text = gesamtAnzahl.ToString();

            }

            catch
            {
                MessageBox.Show("Bitte geben sie die anzahl an produkten ein!");
            }
        }
    }
}

