﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _03_AA_S52_A1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnBerechnen_Click(object sender, EventArgs e)
        {
            double[] gehaltsStufe = new double [10];

            gehaltsStufe[0] = 1000;
            gehaltsStufe[1] = 1100;
            gehaltsStufe[2] = 1200;
            gehaltsStufe[3] = 1300;
            gehaltsStufe[4] = 1400;
            gehaltsStufe[5] = 1500;
            gehaltsStufe[6] = 1600;
            gehaltsStufe[7] = 1700;
            gehaltsStufe[8] = 1800;
            gehaltsStufe[9] = 1900;

            //Alternativ:
            //int[] gehaltsStufe = {1, 2, 3, 4, ..., 10};
            //double[] gehaltEuro = {1000, 1100, 1200, ..., 1900};

            try
            {
                int vordienstJahre = Convert.ToInt16(txtEingabeJahre.Text);

                if (vordienstJahre >= 10)
                {
                    vordienstJahre = 10;
                }
                else if ( vordienstJahre == 0)
                {
                    vordienstJahre = 1;
                }

                txtAusgabeMindestgehalt.Text = gehaltsStufe[vordienstJahre - 1].ToString("0.00");
            }
            catch
            {
                MessageBox.Show("Bitte geben Sie einen positiven Wert ein!");
            }

        }
    }
}
