﻿namespace _03_AA_S52_A1
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEingabeJahre = new System.Windows.Forms.Label();
            this.txtEingabeJahre = new System.Windows.Forms.TextBox();
            this.lblMindestgehalt = new System.Windows.Forms.Label();
            this.txtAusgabeMindestgehalt = new System.Windows.Forms.TextBox();
            this.btnBerechnen = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblEingabeJahre
            // 
            this.lblEingabeJahre.AutoSize = true;
            this.lblEingabeJahre.Location = new System.Drawing.Point(168, 54);
            this.lblEingabeJahre.Name = "lblEingabeJahre";
            this.lblEingabeJahre.Size = new System.Drawing.Size(185, 13);
            this.lblEingabeJahre.TabIndex = 0;
            this.lblEingabeJahre.Text = "Eingabe der Vordienstzeiten in Jahren";
            // 
            // txtEingabeJahre
            // 
            this.txtEingabeJahre.Location = new System.Drawing.Point(368, 51);
            this.txtEingabeJahre.Name = "txtEingabeJahre";
            this.txtEingabeJahre.Size = new System.Drawing.Size(100, 20);
            this.txtEingabeJahre.TabIndex = 1;
            // 
            // lblMindestgehalt
            // 
            this.lblMindestgehalt.AutoSize = true;
            this.lblMindestgehalt.Location = new System.Drawing.Point(168, 167);
            this.lblMindestgehalt.Name = "lblMindestgehalt";
            this.lblMindestgehalt.Size = new System.Drawing.Size(73, 13);
            this.lblMindestgehalt.TabIndex = 2;
            this.lblMindestgehalt.Text = "Mindestgehalt";
            // 
            // txtAusgabeMindestgehalt
            // 
            this.txtAusgabeMindestgehalt.Location = new System.Drawing.Point(368, 160);
            this.txtAusgabeMindestgehalt.Name = "txtAusgabeMindestgehalt";
            this.txtAusgabeMindestgehalt.ReadOnly = true;
            this.txtAusgabeMindestgehalt.Size = new System.Drawing.Size(100, 20);
            this.txtAusgabeMindestgehalt.TabIndex = 3;
            // 
            // btnBerechnen
            // 
            this.btnBerechnen.Location = new System.Drawing.Point(230, 95);
            this.btnBerechnen.Name = "btnBerechnen";
            this.btnBerechnen.Size = new System.Drawing.Size(211, 40);
            this.btnBerechnen.TabIndex = 4;
            this.btnBerechnen.Text = "Mindestgehalt berechnen";
            this.btnBerechnen.UseVisualStyleBackColor = true;
            this.btnBerechnen.Click += new System.EventHandler(this.btnBerechnen_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnBerechnen);
            this.Controls.Add(this.txtAusgabeMindestgehalt);
            this.Controls.Add(this.lblMindestgehalt);
            this.Controls.Add(this.txtEingabeJahre);
            this.Controls.Add(this.lblEingabeJahre);
            this.Name = "Form1";
            this.Text = " ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEingabeJahre;
        private System.Windows.Forms.TextBox txtEingabeJahre;
        private System.Windows.Forms.Label lblMindestgehalt;
        private System.Windows.Forms.TextBox txtAusgabeMindestgehalt;
        private System.Windows.Forms.Button btnBerechnen;
    }
}

